package com.app.web.entidad;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Voto {

	@Id
	private int codVoto;
	private int idenCandidato;
	private int identificacion;
	private String fechaHoraString;
	
	
	
	public Voto() {
	}
	
	public Voto(int codVoto, int idenCandidato, int identificacion, String fechaHoraString) {
		this.codVoto = codVoto;
		this.idenCandidato = idenCandidato;
		this.identificacion = identificacion;
		this.fechaHoraString = fechaHoraString;
	}
	public int getCodVoto() {
		return codVoto;
	}
	public void setCodVoto(int codVoto) {
		this.codVoto = codVoto;
	}
	public int getIdenCandidato() {
		return idenCandidato;
	}
	public void setIdenCandidato(int idenCandidato) {
		this.idenCandidato = idenCandidato;
	}
	public int getIdentificacion() {
		return identificacion;
	}
	public void setIdentificacion(int identificacion) {
		this.identificacion = identificacion;
	}
	public String getFechaHoraString() {
		return fechaHoraString;
	}
	public void setFechaHoraString(String fechaHoraString) {
		this.fechaHoraString = fechaHoraString;
	}
	@Override
	public String toString() {
		return "Voto [codVoto=" + codVoto + ", idenCandidato=" + idenCandidato + ", identificacion=" + identificacion
				+ ", fechaHoraString=" + fechaHoraString + "]";
	}
	
	
}
