package com.app.web.entidad;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Candidato {

	@Id
	private int idenCandidato;
	private String nombre;
	private String foto;
	private String descripcion;
	private String urlPartido;
	
	
	
	public Candidato() {
	}
	public Candidato(int idenCandidato, String nombre, String foto, String descripcion, String urlPartido) {
		this.idenCandidato = idenCandidato;
		this.nombre = nombre;
		this.foto = foto;
		this.descripcion = descripcion;
		this.urlPartido = urlPartido;
	}
	public int getIdenCandidato() {
		return idenCandidato;
	}
	public void setIdenCandidato(int idenCandidato) {
		this.idenCandidato = idenCandidato;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getUrlPartido() {
		return urlPartido;
	}
	public void setUrlPartido(String urlPartido) {
		this.urlPartido = urlPartido;
	}
	@Override
	public String toString() {
		return "Candidato [idenCandidato=" + idenCandidato + ", nombre=" + nombre + ", foto=" + foto + ", descripcion="
				+ descripcion + ", urlPartido=" + urlPartido + "]";
	}
	
	
	
}
