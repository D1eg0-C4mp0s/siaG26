package com.app.web.controlador;

import java.util.Optional;

import javax.persistence.Id;
import javax.swing.JOptionPane;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.web.entidad.Votante;
import com.app.web.servicio.VotanteService;

@Controller
public class votanteControlador {
	
	private VotanteService votanteService;

	@PostMapping("/validar")
	public String validar(@Validated Votante votante, Integer id) {
		try {
			Optional<Votante> objVotante = votanteService.findById(id);
			if(objVotante != null) {
				return "redirect:/index";
			}
			else {
				JOptionPane.showMessageDialog(null, "Usuario desconocido!");
				return "/votaapp";
			}
		}catch (Exception e) {
			System.out.println("error " +e);
		}
		return "redirect:/votaapp";
	}
	
}
