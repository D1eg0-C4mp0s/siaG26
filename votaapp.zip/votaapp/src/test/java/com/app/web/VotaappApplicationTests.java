package com.app.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotaappApplicationTests {

	@Test
	void contextLoads() {
	}

}
