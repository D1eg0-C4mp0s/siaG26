package com.app.web.entidad;



public class Resultados {

private int canVotos;

public int getCanVotos() {
	return canVotos;
}

public void setCanVotos(int canVotos) {
	this.canVotos = canVotos;
}
	

	
}
